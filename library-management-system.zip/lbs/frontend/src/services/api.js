import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api",
});

export const fetchBooks = () => API.get("/books");
export const createBook = (book) => API.post("/books", book);
export const removeBook = (id) => API.delete(`/books/${id}`);
