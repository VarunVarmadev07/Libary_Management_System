import { useEffect, useState } from "react";
import { fetchBooks, removeBook } from "./services/api";
import AddBook from "./components/AddBook";
import BookList from "./components/BookList";
import "./index.css";

const App = () => {
  const [books, setBooks] = useState([]);

  const loadBooks = async () => {
    const res = await fetchBooks();
    setBooks(res.data);
  };

  const deleteBook = async (id) => {
    await removeBook(id);
    loadBooks();
  };

  useEffect(() => {
    loadBooks();
  }, []);

  return (
    <div className="container">
      <h1>📚 Library Management System</h1>

      <AddBook onBookAdded={loadBooks} />
      <BookList books={books} onDelete={deleteBook} />
    </div>
  );
};

export default App;
