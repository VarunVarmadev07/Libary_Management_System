const BookList = ({ books, onDelete }) => {
  return (
    <div className="card">
      <h2>Book List</h2>

      {books.length === 0 && <p>No books available</p>}

      {books.map((book) => (
        <div className="book-item" key={book._id}>
          <span>
            <strong>{book.title}</strong> — {book.author}
          </span>
          <button onClick={() => onDelete(book._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default BookList;
